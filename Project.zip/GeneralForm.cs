﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Windows.Forms.DataVisualization.Charting;

namespace Kate
{
    public partial class GeneralForm : Form
    {
        
        public GeneralForm()
        {
            InitializeComponent();
            this.FormClosing += GeneralForm_FormClosing;
        }
        List<Products> products=new List<Products>();
        private void GeneralForm_Load(object sender, EventArgs e)
        {
            SQLiteConnection connection = new SQLiteConnection("Integrated Security = SSPI; Data Source = Products.db");
            connection.Open();
            var command = connection.CreateCommand();
            command.CommandText = @"SELECT IDПродукта, Наименование, Категория, ЦенаШТ ,Скидка ,СкидЦена ,Наличие FROM Products";
            using (var rd = command.ExecuteReader())
            {
                while(rd.Read())
                {
                    int ProductID = rd.GetInt32(0);
                    string ProdectName=rd.GetString(1);
                    string Category=rd.GetString(2);
                    int  Price=rd.GetInt32(3);
                    string Discount=rd.GetString(4);
                    int DiscountPrice=rd.GetInt32(5);
                    int Quantity=rd.GetInt32(6);
                    products.Add(new Products(ProductID, ProdectName, Category, Price, Discount, DiscountPrice,Quantity));
                    
                }
            }
            connection.Close();
            dataGridView1.DataSource = products;
            // Обновить данные графика
            chart1.Series[0].Points.Clear();
            int totalItemCount = products.Count;
            var categoryCounts = products.GroupBy(item => item.Категория1).Select(group => new
            {
                Category = group.Key,
                Count = group.Count()
            });

            foreach (var category in categoryCounts)
            {
                // Вычислить процентное соотношение
                double percentage = (double)category.Count / totalItemCount * 100;

                // Добавить данные на график
                var point = chart1.Series[0].Points.Add(category.Count);
                point.Label = $"{percentage:F1}%"; // Установить подпись точки данных как процент
                point.LegendText = category.Category; // Установить подпись в сноске

                // Если нужно отобразить проценты внутри сектора диаграммы, раскомментируйте следующую строку:
                point.Label = $"{percentage:F1}%";
            }
            chart1.Series[0].Font = new Font("Calibri", 11f, FontStyle.Regular);
            // Изменить шрифт для подписей в сноске
            chart1.Legends[0].Font = new Font("Calibri", 11f, FontStyle.Bold); // Установить шрифт и размер
            chart1.Legends[0].ForeColor = Color.Black; // Установить цвет шрифта

            // Настроить отображение подписей данных на графике
            chart1.Series[0].IsValueShownAsLabel = false; // Отключить отображение подписей данных по умолчанию
            chart1.Series[0]["PieLabelStyle"] = "Intside"; // Установить стиль подписей данных на "Outside"
            comboBox1.Items.Add("Напитки");
            comboBox1.Items.Add("Готовая еда");
            comboBox1.Items.Add("Закуски");
            comboBox1.Items.Add("Молочные продукты и сыры");
            comboBox1.Items.Add("Морепродукты");
            comboBox1.Items.Add("Мучные изделия");
            comboBox1.Items.Add("Приправы");
            comboBox1.Items.Add("Сладости");
            comboBox1.Items.Add("Топинги");
            comboBox1.Items.Add("Скидочный товар");
            richTextBox1.Hide();
            chart1.Hide();
            labeldiagram.Hide();
            labelrich.Hide();
        }
        private void GeneralForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                IEnumerable<Products> num = products.Where(n => n.Категория1 == "Напитки");
                this.dataGridView1.DataSource = num.ToArray();
            }
           else if (comboBox1.SelectedIndex == 1)
            {
                IEnumerable<Products> num = products.Where(n => n.Категория1 == "Готовая еда");
                this.dataGridView1.DataSource = num.ToArray();
            }
           else if (comboBox1.SelectedIndex == 2)
            {
                IEnumerable<Products> num = products.Where(n => n.Категория1  == "Закуски");
                this.dataGridView1.DataSource = num.ToArray();
            }
           else if (comboBox1.SelectedIndex == 3)
            {
                IEnumerable<Products> num = products.Where(n => n.Категория1 == "Молочные продукты и сыры");
                this.dataGridView1.DataSource = num.ToArray();
            }
           else if (comboBox1.SelectedIndex == 4)
            {
                IEnumerable<Products> num = products.Where(n => n.Категория1 == "Морепродукты");
                this.dataGridView1.DataSource = num.ToArray();
            }
           else if (comboBox1.SelectedIndex == 5)
            {
                IEnumerable<Products> num = products.Where(n => n.Категория1 == "Мучные изделия");
                this.dataGridView1.DataSource = num.ToArray();
            }
            else if (comboBox1.SelectedIndex == 6)
            {
                IEnumerable<Products> num = products.Where(n => n.Категория1 == "Приправы");
                this.dataGridView1.DataSource = num.ToArray();
            }
           else if (comboBox1.SelectedIndex == 7)
            {
                IEnumerable<Products> num = products.Where(n => n.Категория1 == "Сладости");
                this.dataGridView1.DataSource = num.ToArray();
            }
           else if (comboBox1.SelectedIndex == 8)
            {
                IEnumerable<Products> num = products.Where(n => n.Категория1 == "Топинги");
                this.dataGridView1.DataSource = num.ToArray();
            }
           else if (comboBox1.SelectedIndex == 9)
            {
                IEnumerable<Products> num = products.Where(n => n.Скидка1 == "Скидочный товар");
                this.dataGridView1.DataSource = num.ToArray();
            }
          
        }

        private void Update_Click(object sender, EventArgs e)
        {
            List<Products> sortedList = products.OrderBy(n => n.IDПродукта1).ToList();

            // Update dataGridView1 with the sorted data
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = sortedList;
            chart1.Hide();
            richTextBox1.Hide();
            labeldiagram.Hide();
            labelrich.Hide();
        }

        private void name_Click(object sender, EventArgs e)
        {
            List<Products> sortedList = products.OrderBy(n => n.Наименование1).ToList();

            // Update dataGridView1 with the sorted data
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = sortedList;
        }

        private void category_Click(object sender, EventArgs e)
        {
            List<Products> sortedList = products.OrderBy(n => n.Категория1).ToList();

            // Update dataGridView1 with the sorted data
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = sortedList;
        }

        private void price_Click(object sender, EventArgs e)
        {
            List<Products> sortedList = products.OrderBy(n => n.Ценазаштуку1).ToList();

            // Update dataGridView1 with the sorted data
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = sortedList;
        }

        private void quantity_Click(object sender, EventArgs e)
        {
            List<Products> sortedList = products.OrderBy(n => n.Наличие1).ToList();

            // Update dataGridView1 with the sorted data
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = sortedList;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            List<Products> sortedList = products.OrderBy(n => n.IDПродукта1).ToList();

            // Update dataGridView1 with the sorted data
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = sortedList;
        }

        private void button6_Click(object sender, EventArgs e)
        {

            string category = textBox1.Text;

            // Выполните необходимые действия для выполнения поиска по имени продукта и престижу.
            // Например, используйте LINQ-запрос для фильтрации списка electronics.

            IEnumerable<Products> numQuery = products;
            if (!string.IsNullOrWhiteSpace(category))
            {
                // Проверяем, есть ли в списке продуктов категория, точно соответствующая введенному тексту
                bool isValidCategory = products.Any(p => string.Equals(p.Категория1, category, StringComparison.OrdinalIgnoreCase));

                if (isValidCategory)
                {
                    numQuery = numQuery.Where(n => string.Equals(n.Категория1, category, StringComparison.OrdinalIgnoreCase));
                }
                else
                {
                    MessageBox.Show("Введите верное название категории продукта");
                    return; // Прекратить выполнение кода, чтобы результаты не отображались неправильно
                }
            }
            else
            {
                MessageBox.Show("Введите верное название категории продукта");
                return; // Прекратить выполнение кода, чтобы результаты не отображались неправильно
            }

            richTextBox1.Clear();

            foreach (var item in numQuery)
            {
                richTextBox1.AppendText($"ID: {item.IDПродукта1}\n");
                richTextBox1.AppendText($"Name: {item.Наименование1}\n");
                richTextBox1.AppendText($"Category: {item.Категория1}\n");
                richTextBox1.AppendText($"Price: {item.Ценазаштуку1}\n");
                richTextBox1.AppendText($"Model: {item.Скидка1}\n");
                richTextBox1.AppendText($"Quantity: {item.ЦенаCоCкидкой1}\n");
                richTextBox1.AppendText($"Prestige: {item.Наличие1}\n");
                richTextBox1.AppendText("_______________________\n");
            }
            richTextBox1.Show();
            chart1.Show();
            textBox1.Clear();
            labelrich.Show();
            labeldiagram.Show();
        }
    }
}
