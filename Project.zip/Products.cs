﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kate
{
    internal class Products
    {
        private int IDПродукта;
        private string Наименование;
        private string Категория;
        private int Ценазаштуку;
        private string Скидка;
        private int ЦенаCоCкидкой;
        private int Наличие;

        public Products(int iDПродукта, string наименование, string категория, int ценазаштуку, string скидка, int ценаCоCкидкой, int наличие)
        {
            IDПродукта = iDПродукта;
            Наименование = наименование;
            Категория = категория;
            Ценазаштуку = ценазаштуку;
            Скидка = скидка;
            ЦенаCоCкидкой = ценаCоCкидкой;
            Наличие = наличие;
        }

        public int IDПродукта1 { get => IDПродукта; set => IDПродукта = value; }
        public string Наименование1 { get => Наименование; set => Наименование = value; }
        public string Категория1 { get => Категория; set => Категория = value; }
        public int Ценазаштуку1 { get => Ценазаштуку; set => Ценазаштуку = value; }
        public string Скидка1 { get => Скидка; set => Скидка = value; }
        public int ЦенаCоCкидкой1 { get => ЦенаCоCкидкой; set => ЦенаCоCкидкой = value; }
        public int Наличие1 { get => Наличие; set => Наличие = value; }
    }
}
