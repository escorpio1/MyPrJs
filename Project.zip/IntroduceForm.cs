﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kate
{
    public partial class IntroduceForm : Form
    {
        public IntroduceForm()
        {
            InitializeComponent();
            this.FormClosing += IntroduceForm_FormClosing;
        }

        private void IntroduceForm_Load(object sender, EventArgs e)
        {
           
        }

        private void enter_Click(object sender, EventArgs e)
        {
            GeneralForm generalForm = new GeneralForm();
            generalForm.Show();
            this.Hide();
        }
        private void IntroduceForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
